package com.example.adminpage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

import missing.namespace.R;

public class UserAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<Object> items = new ArrayList<>();

    public static final int TYPE_HEADER = 0;
    public static final int TYPE_ITEM = 1;

    public UserAdapter(List<User> users) {
        categorizeUsers(users);
    }

    private void categorizeUsers(List<User> users) {
        // Add Custodian Header
        items.add("Custodians");
        for (int i = 0; i < 3; i++) {
            items.add(users.get(i));
        }

        // Add other headers and users as needed
        items.add("Admins");
        for (int i = 3; i < 5; i++) {
            items.add(users.get(i));
        }

        items.add("Faculty");
        for (int i = 5; i < 7; i++) {
            items.add(users.get(i));
        }

        items.add("Students");
        for (int i = 7; i < 10; i++) {
            items.add(users.get(i));
        }
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position) instanceof String ? TYPE_HEADER : TYPE_ITEM;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_HEADER) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.header_item, parent, false);
            return new HeaderViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_item, parent, false);
            return new UserViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof HeaderViewHolder) {
            ((HeaderViewHolder) holder).title.setText((String) items.get(position));
        } else {
            User user = (User) items.get(position);
            ((UserViewHolder) holder).name.setText(user.getName());
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView title;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.header_title);
        }
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView name;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.user_name);
        }
    }
}
