package com.example.adminpage;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.imageview.ShapeableImageView;

public class MainActivity extends AppCompatActivity {

    // Define views
    private TabLayout tabLayout;
    private CardView card1, card2, card3, card4, card5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        tabLayout = findViewById(R.id.tab_layout);
        card1 = findViewById(R.id.card1);
        card2 = findViewById(R.id.card2);
        card3 = findViewById(R.id.card3);
        card4 = findViewById(R.id.card4);
        card5 = findViewById(R.id.card5);

        // Set up TabLayout with a listener
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                // Handle tab selection
                String selectedTab = tab.getText().toString();
                Toast.makeText(MainActivity.this, selectedTab + " Tab Selected", Toast.LENGTH_SHORT).show();
                // Optionally, handle tab-specific logic here
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                // Optionally, handle tab unselection logic
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Optionally, handle reselection logic
            }
        });

        // Set click listeners for each card's ImageButton (arrow button)
        findViewById(R.id.arrow_button1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToNextPage(1);
            }
        });

        findViewById(R.id.arrow_button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToNextPage(2);
            }
        });

        findViewById(R.id.arrow_button3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToNextPage(3);
            }
        });

        findViewById(R.id.arrow_button4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToNextPage(4);
            }
        });

        findViewById(R.id.arrow_button5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToNextPage(5);
            }
        });
    }

    private void navigateToNextPage(int cardNumber) {
        // Logic to navigate to another page/activity
        // For now, show a toast to indicate the action
        String message = "Navigating from Card " + cardNumber;
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();

        // Example: you could start a new activity here
        // Intent intent = new Intent(MainActivity.this, NextActivity.class);
        // startActivity(intent);
    }
}
