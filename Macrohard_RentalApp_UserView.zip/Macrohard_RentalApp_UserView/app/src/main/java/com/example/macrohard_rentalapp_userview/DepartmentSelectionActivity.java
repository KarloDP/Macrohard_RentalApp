package com.example.macrohard_rentalapp_userview;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DepartmentSelectionActivity extends AppCompatActivity {

    private static final String TAG = "DepartmentSelectionActivity";
    private RecyclerView rvOptions;
    private boolean isOptionsVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_department_selection);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Toolbar toolbar = findViewById(R.id.include_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        ImageButton btnOptionSelector = findViewById(R.id.btn_option_selector);
        rvOptions = findViewById(R.id.rv_options);

        if (btnOptionSelector == null) {
            Log.e(TAG, "btn_option_selector not found");
        }

        // Set up RecyclerView
        rvOptions.setLayoutManager(new LinearLayoutManager(this));
        List<String> options = new ArrayList<>();
        options.add("Choice 1");
        options.add("Choice 2");
        options.add("Choice 3");
        OptionsAdapter adapter = new OptionsAdapter(options);
        rvOptions.setAdapter(adapter);

        btnOptionSelector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toggle RecyclerView visibility
                if (isOptionsVisible) {
                    rvOptions.setVisibility(View.GONE);
                } else {
                    rvOptions.setVisibility(View.VISIBLE);
                }
                isOptionsVisible = !isOptionsVisible;
                Log.d(TAG, "Option selector button clicked");
            }
        });
    }
}