package com.example.macrohard_rentalapp_userview;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.widget.ImageButton;

public class ReservedItemsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserved_items);

        Toolbar toolbar = findViewById(R.id.include_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        // Set up OptionSelection
        ImageButton btnOptionSelector = findViewById(R.id.btn_option_selector);
        OptionSelection optionSelection = new OptionSelection();
        optionSelection.setupOptionSelection(this, findViewById(android.R.id.content), toolbar, btnOptionSelector);

        // Other initialization code
    }
}