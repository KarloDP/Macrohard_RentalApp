package com.example.macrohard_rentalapp_userview;

import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ToolbarOptionSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    protected void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.include_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        ImageButton btnOptionSelector = findViewById(R.id.btn_option_selector);
        ImageButton btnChecklist = findViewById(R.id.btn_checklist);
        ImageButton btnNotifications = findViewById(R.id.btn_notifications);
        ImageButton btnProfile = findViewById(R.id.btn_profile);

        btnOptionSelector.setOnClickListener(v -> {
            // Handle option selector click
        });

        btnChecklist.setOnClickListener(v -> {
            // Handle checklist click
        });

        btnNotifications.setOnClickListener(v -> {
            // Handle notifications click
        });

        btnProfile.setOnClickListener(v -> {
            // Handle profile click
        });
    }

    protected void setupRecyclerView() {
        RecyclerView rvOptions = findViewById(R.id.rv_options);
        rvOptions.setLayoutManager(new LinearLayoutManager(this));
        List<String> options = new ArrayList<>();
        options.add("Home 1");
        options.add("Department Selection");
        options.add("Wishlist");
        OptionsAdapter adapter = new OptionsAdapter(this, options); // Pass context and options
        rvOptions.setAdapter(adapter);
    }
}