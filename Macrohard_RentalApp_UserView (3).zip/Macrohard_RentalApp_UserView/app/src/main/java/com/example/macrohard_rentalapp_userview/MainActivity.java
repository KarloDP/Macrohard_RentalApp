package com.example.macrohard_rentalapp_userview;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private RecyclerView rvOptions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Toolbar toolbar = findViewById(R.id.include_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        Button btnDepartmentSelection = findViewById(R.id.btn_department_selection);
        Button btnItemWishlist = findViewById(R.id.btn_item_wishlist);
        Button btnItemReservation = findViewById(R.id.btn_item_reservation);
        rvOptions = findViewById(R.id.rv_options);

        if (btnDepartmentSelection == null || btnItemWishlist == null || btnItemReservation == null) {
            Log.e(TAG, "One or more buttons not found");
        }

        btnDepartmentSelection.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DepartmentSelectionActivity.class);
            startActivity(intent);
        });

        btnItemWishlist.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ItemWishlistActivity.class);
            startActivity(intent);
        });

        btnItemReservation.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ReservedItemsActivity.class);
            startActivity(intent);
        });

        // Set up RecyclerView
        rvOptions.setLayoutManager(new LinearLayoutManager(this));
        List<String> options = new ArrayList<>();
        options.add("Home");
        options.add("Department Selection");
        options.add("Wishlist");
        OptionsAdapter adapter = new OptionsAdapter(this, options); // Pass context and options
        rvOptions.setAdapter(adapter);

        // Set up OptionSelection
        ImageButton btnOptionSelector = findViewById(R.id.btn_option_selector);
        OptionSelection optionSelection = new OptionSelection();
        optionSelection.setupOptionSelection(this, findViewById(android.R.id.content), toolbar, btnOptionSelector);
    }
}