package com.example.macrohard_rentalapp_userview;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import androidx.appcompat.widget.Toolbar;

public class DepartmentSelectionActivity extends ToolbarOptionSelectionActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department_selection);
        setupToolbar();
        setupRecyclerView();

        Button btnDepartment1 = findViewById(R.id.btn_department_1);
        Button btnDepartment2 = findViewById(R.id.btn_department_2);
        Button btnDepartment3 = findViewById(R.id.btn_department_3);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DepartmentSelectionActivity.this, ItemSelectionActivity.class);
                startActivity(intent);
            }
        };

        btnDepartment1.setOnClickListener(listener);
        btnDepartment2.setOnClickListener(listener);
        btnDepartment3.setOnClickListener(listener);

        // Set up OptionSelection
        Toolbar toolbar = findViewById(R.id.include_toolbar);
        ImageButton btnOptionSelector = findViewById(R.id.btn_option_selector);
        OptionSelection optionSelection = new OptionSelection();
        optionSelection.setupOptionSelection(this, findViewById(android.R.id.content), toolbar, btnOptionSelector);
    }
}