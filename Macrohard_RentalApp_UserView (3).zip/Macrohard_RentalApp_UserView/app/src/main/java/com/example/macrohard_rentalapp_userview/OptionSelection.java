package com.example.macrohard_rentalapp_userview;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.List;

public class OptionSelection {

    private static final String TAG = "OptionSelection";
    private RecyclerView rvOptions;

    public void setupOptionSelection(Context context, View mainView, Toolbar toolbar, ImageButton btnOptionSelector) {
        ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (btnOptionSelector == null) {
            Log.e(TAG, "btn_option_selector not found");
            return;
        }

        btnOptionSelector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOptionsDialog(context);
                Log.d(TAG, "Option selector button clicked");
            }
        });
    }

    private void showOptionsDialog(Context context) {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context);
        View bottomSheetView = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_options, null);
        bottomSheetDialog.setContentView(bottomSheetView);

        rvOptions = bottomSheetView.findViewById(R.id.rv_options);
        rvOptions.setLayoutManager(new LinearLayoutManager(context));
        List<String> options = new ArrayList<>();
        options.add("Home");
        options.add("Department Selection");
        options.add("Item Wishlist");
        OptionsAdapter adapter = new OptionsAdapter(context, options);
        rvOptions.setAdapter(adapter);

        bottomSheetDialog.show();
    }
}